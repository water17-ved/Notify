# JEE Test Analysis → Custom Notify sync

The Android app now accepts revision plans through:

`customnotify://revision-sync?payload=<URL-safe-base64-JSON>`

The Test Analysis page sends the generated plan automatically when **Create 1–2 Day Plan** is pressed, and also exposes **Sync to Custom Notify** for a manual retry.

Only sessions dated Today or Tomorrow are imported. Re-syncing the same analysis replaces its old imported plan, making the operation idempotent.

The Android app stores sessions in Room and schedules a notification for each imported session. Tapping **Mark Done** in a notification or the in-app session card marks that revision complete.

Build the Android project with Android Studio/Gradle to produce the APK.

## Home-screen widgets

This build adds four Android home-screen widgets:
- Today's Revision
- 2-Day Revision
- Next Revision
- Revision Progress

All widgets read the same Room revision-session data as the app. They only display pending sessions for today and tomorrow. Syncing a new Test Analysis plan refreshes the widgets; marking a session done from the app or revision notification refreshes them as well. The widget's Done action completes the first pending session and refreshes all widgets.
