package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.AppDatabase
import com.example.data.model.NotificationPriority
import com.example.notification.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class RevisionSessionNotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val sessionId = intent.getStringExtra(NotificationHelper.EXTRA_REVISION_SESSION_ID) ?: return
        val title = intent.getStringExtra(NotificationHelper.EXTRA_TITLE) ?: "⚡ Revision Session"
        val message = intent.getStringExtra(NotificationHelper.EXTRA_MESSAGE) ?: "Complete your planned revision session."
        NotificationHelper.showRevisionNotification(context, sessionId, title, message)
    }
}
