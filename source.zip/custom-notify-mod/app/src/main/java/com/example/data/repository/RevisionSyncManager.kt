package com.example.data.repository

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Base64
import com.example.data.AppDatabase
import com.example.data.model.RevisionSession
import com.example.notification.NotificationHelper
import com.example.widget.RevisionWidgetProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

object RevisionSyncManager {
    const val SCHEME = "customnotify"
    const val HOST = "revision-sync"

    suspend fun handleIntent(context: Context, intent: Intent): Int = withContext(Dispatchers.IO) {
        val uri = intent.data ?: return@withContext 0
        if (uri.scheme != SCHEME || uri.host != HOST) return@withContext 0

        val encoded = uri.getQueryParameter("payload") ?: return@withContext 0
        val json = try {
            String(Base64.decode(encoded, Base64.URL_SAFE or Base64.NO_WRAP), StandardCharsets.UTF_8)
        } catch (_: Exception) {
            return@withContext 0
        }

        val parsed = try { JSONArray(json) } catch (_: Exception) { return@withContext 0 }
        val today = dateOffset(0)
        val tomorrow = dateOffset(1)
        val allowedDates = setOf(today, tomorrow)
        val sessions = mutableListOf<RevisionSession>()

        for (i in 0 until parsed.length()) {
            val o = parsed.optJSONObject(i) ?: continue
            val date = o.optString("date", "")
            if (date !in allowedDates) continue

            val id = o.optString("id", "")
            val analysisId = o.optString("analysisId", "")
            val chapter = o.optString("chapter", "")
            if (id.isBlank() || analysisId.isBlank() || chapter.isBlank()) continue

            sessions += RevisionSession(
                id = id,
                analysisId = analysisId,
                testName = o.optString("testName", "Test Analysis"),
                subject = o.optString("subject", "Other"),
                chapter = chapter,
                topic = o.optString("topic", null),
                priority = o.optString("priority", "MEDIUM"),
                reason = o.optString("reason", "Test-driven revision"),
                mistakeType = o.optString("mistakeType", null),
                questions = o.optJSONArray("questions")?.let { arr ->
                    (0 until arr.length()).joinToString(", ") { arr.optString(it) }
                },
                date = date,
                durationMinutes = o.optInt("durationMinutes", 30).coerceIn(10, 120),
                status = "planned",
                source = "test-analysis",
                createdAt = System.currentTimeMillis()
            )
        }

        if (sessions.isEmpty()) return@withContext 0

        val db = AppDatabase.getDatabase(context)
        // Replace the same analysis' old plan so re-syncing is idempotent.
        sessions.map { it.analysisId }.distinct().forEach { db.revisionSessionDao().deleteForAnalysis(it) }
        db.revisionSessionDao().upsertAll(sessions)

        sessions.forEachIndexed { index, session ->
            NotificationHelper.scheduleRevisionSession(context, session, index)
        }
        RevisionWidgetProvider.updateAll(context)
        sessions.size
    }

    fun dateOffset(offset: Int): String {
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_YEAR, offset)
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.time)
    }
}
