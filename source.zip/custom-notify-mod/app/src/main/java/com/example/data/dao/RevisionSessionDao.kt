package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.RevisionSession
import kotlinx.coroutines.flow.Flow

@Dao
interface RevisionSessionDao {
    @Query("SELECT * FROM revision_sessions ORDER BY date ASC, status ASC, priority ASC, chapter ASC")
    fun getAllSessions(): Flow<List<RevisionSession>>

    @Query("SELECT * FROM revision_sessions WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): RevisionSession?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(sessions: List<RevisionSession>)

    @Update
    suspend fun update(session: RevisionSession)

    @Query("UPDATE revision_sessions SET status = 'completed', completedAt = :completedAt WHERE id = :id")
    suspend fun markCompleted(id: String, completedAt: Long)

    @Query("DELETE FROM revision_sessions WHERE analysisId = :analysisId")
    suspend fun deleteForAnalysis(analysisId: String)

    @Query("SELECT * FROM revision_sessions WHERE status != 'completed' AND date IN (:dates) ORDER BY date ASC, priority ASC")
    suspend fun getPendingForDates(dates: List<String>): List<RevisionSession>
}
