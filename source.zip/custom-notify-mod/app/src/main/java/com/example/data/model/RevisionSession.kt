package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "revision_sessions")
data class RevisionSession(
    @PrimaryKey val id: String,
    val analysisId: String,
    val testName: String,
    val subject: String,
    val chapter: String,
    val topic: String? = null,
    val priority: String = "MEDIUM",
    val reason: String = "Test-driven revision",
    val mistakeType: String? = null,
    val questions: String? = null,
    val date: String,
    val durationMinutes: Int = 30,
    val status: String = "planned",
    val source: String = "test-analysis",
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null
)
