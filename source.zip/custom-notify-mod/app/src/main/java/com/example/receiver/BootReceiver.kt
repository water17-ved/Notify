package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.AppDatabase
import com.example.notification.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == "android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED"
        ) {
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val db = AppDatabase.getDatabase(context)
                    val activeNotifications = db.notificationDao().getActiveNotificationsDirect()
                    for (notification in activeNotifications) {
                        NotificationHelper.scheduleAlarm(context, notification)
                    }
                    val today = com.example.data.repository.RevisionSyncManager.dateOffset(0)
                    val tomorrow = com.example.data.repository.RevisionSyncManager.dateOffset(1)
                    val revisionSessions = db.revisionSessionDao().getPendingForDates(listOf(today, tomorrow))
                    revisionSessions.forEachIndexed { index, session ->
                        NotificationHelper.scheduleRevisionSession(context, session, index)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
